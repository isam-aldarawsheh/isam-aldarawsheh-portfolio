# Key Achievements

- Published **2,000+ automotive articles** across my career.
- Published **540+ articles, reviews, buying guides, and editorial pieces** in Arabic and English in the recent portfolio period.
- Established an SEO content foundation that generated **181,024 organic page views in 2022**.
- Increased article views to **412K in 2023**, representing **127.4% YoY growth**.
- Reached **625K annual views in 2024**, a further **51.9% YoY increase**.
- Maintained **528K views in 2025**, sustaining strong organic visibility in a more competitive environment.
- Led full English-Arabic localization across a website.
- Developed and maintained a structured automotive database.
- Led a team of **three employees** responsible for automotive data entry.
- Produced sponsored and promotional content for major automotive brands.
- Covered major regional automotive events and industry launches.
- Produced automotive television and multimedia content.
