# Arabsturbo.com — Senior Editor

**February 2014 – August 2018**

## Highlights

- Covered major automotive events including the Dubai International Motor Show.
- Produced interviews, breaking news, launches, reviews, and high-volume daily automotive content.
- Authored **5–7 automotive articles per day** in a high-volume digital newsroom.
- Developed sponsored content for brands including Michelin, Cadillac, Chevrolet, Honda, and Dodge.
- Produced Top 10 video content and test drives focused on audience engagement.
- Managed automotive content distribution across social platforms.
- Contributed to website traffic growth, search visibility, engagement, and audience development.
