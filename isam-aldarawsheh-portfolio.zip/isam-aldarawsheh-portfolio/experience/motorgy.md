# Motorgy.com — Senior Editor

**March 2021 – Present**

Motorgy is a Kuwait-focused automotive marketplace and digital platform for buying and selling cars.

## Responsibilities & Contributions

- Published **450+ articles, tips, and buying guides** supporting organic search visibility and audience acquisition.
- Published **70+ full car reviews** covering important models in the Kuwaiti market.
- Optimized automotive content through keyword targeting, internal linking, and on-page SEO.
- Led **English-to-Arabic translation, localization, and SEO adaptation** across automotive news, reviews, features, and buying guides.
- Ensured consistency in Arabic tone, terminology, structure, and search intent.
- Built and maintained a structured automotive database covering manufacturers, models, model years, and trim levels.
- Led a **team of three employees** responsible for automotive data entry and database maintenance.
- Collaborated with UI/UX, development, and operations teams to improve editorial workflows, content discoverability, and user experience.
