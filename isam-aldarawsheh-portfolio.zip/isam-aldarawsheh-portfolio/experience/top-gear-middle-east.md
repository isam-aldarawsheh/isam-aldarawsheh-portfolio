# Top Gear Middle East — Senior Editor

**October 2014 – December 2014**

## Highlights

- Authored automotive reviews and editorial content.
- Maintained editorial accuracy and consistency in automotive reporting.
- Worked within the standards and editorial voice of a leading regional automotive brand.
