# Earlier Automotive & Media Experience

## Speeed.com / ArabGT.com — Editor
**January 2013 – September 2013**

Produced high-volume automotive news and reviews, verified automotive data, and supported SEO-driven publishing workflows.

## Arab Motors TV / ArabGT.com — Editor
**April 2009 – December 2012**

Produced daily automotive and motorsport news for broadcast and digital distribution. Developed programs covering classic cars, automotive history, and industry topics.

## Auto One TV — Editor / Production Officer
**March 2008 – April 2009**

Produced automotive news, coordinated broadcast segments, developed editorial concepts, handled advertising SMS integration, and reviewed video content using Adobe Premiere Pro.
