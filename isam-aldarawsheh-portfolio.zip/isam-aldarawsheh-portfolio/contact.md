# Contact

**Isam Al Darawsheh**  
Senior Editor | Content Creator | SEO Content Specialist | Digital Publishing Expert

- Email: isam.darawsheh@gmail.com
- LinkedIn: https://www.linkedin.com/in/isam-al-darawsheh
- GitHub: https://github.com/isam-aldarawsheh

I am open to senior opportunities in editorial management, content strategy, SEO, localization, digital publishing, communications, AI content evaluation, and automotive media across the GCC and wider MENA region.
