# Automotive Content & Multimedia

Beyond written journalism, my experience includes video and broadcast production.

## Examples

- Top 10 video formats
- Test-drive content
- Automotive history programs
- Classic-car features
- Industry programming
- Broadcast segment development
- Social media publishing and optimization

This multimedia background supports a broader digital publishing skill set and allows me to work across text, video, social, and web content.
