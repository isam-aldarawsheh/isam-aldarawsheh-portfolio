# Automotive Journalism

Automotive journalism has been the central specialization of my career for more than 18 years.

I have covered the full automotive spectrum, including:

- Breaking automotive news
- Industry developments
- New vehicle launches
- Full vehicle reviews
- Buying guides
- Classic cars
- Luxury cars
- Performance cars and supercars
- Motorsport
- Automotive technology
- Major regional automotive events

My experience includes work with **Top Gear Middle East, ArabGT, Arabsturbo, Motorgy**, and other regional automotive media platforms.

My automotive background is supported by broad editorial skills, meaning I can translate specialist knowledge into content that is technically accurate while remaining accessible and engaging.
