# SEO Content Strategy

My SEO work sits at the intersection of editorial judgment and search performance.

## How I Approach Content

1. Identify the audience question and search intent.
2. Research primary and related keywords.
3. Build a clear editorial structure around the topic.
4. Write useful content rather than producing pages solely for keywords.
5. Optimize headings, metadata, internal links, and content structure.
6. Review performance using Google Analytics 4 and Search Console.
7. Refine content based on search visibility, engagement, and user needs.

## Relevant Experience

I used this approach to develop automotive reviews, buying guides, tips, and news content for Motorgy, contributing to sustained organic traffic growth and improved search visibility.
