# Skills

## Editorial

- Editorial Management
- Editorial Strategy
- News Writing & Editing
- Long-form Content
- Digital Publishing
- Content Management
- Fact-Checking & Quality Assurance
- Editorial Planning

## SEO & Digital

- SEO Content Optimization
- Keyword Research
- Internal Linking
- Organic Traffic Growth
- Google Analytics 4 (GA4)
- Google Search Console
- WordPress
- CMS Management
- Content Performance Analysis
- Social Media Content

## Language & Localization

- Arabic: Native
- English: Fluent
- English-to-Arabic Translation
- Website Localization
- Terminology Management
- GCC/MENA Cultural Adaptation

## Tools

- ChatGPT
- Claude
- WordPress
- Google Analytics 4
- Google Search Console
- Yoast
- Adobe Premiere Pro
- Photoshop
- Canva
- HTML/CSS
- UX/UI Principles
