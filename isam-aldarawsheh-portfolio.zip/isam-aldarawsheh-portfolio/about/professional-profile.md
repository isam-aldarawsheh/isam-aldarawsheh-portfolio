# Professional Profile

I am a Senior Editor and digital content professional with more than 18 years of experience in journalism, editorial management, SEO, digital publishing, and English-Arabic localization.

My career has been built around turning complex information into clear, useful, and engaging content. I have worked across automotive news, reviews, buying guides, sponsored content, multimedia, social media, and digital publishing, with a strong focus on accuracy and audience relevance.

My current work at Motorgy combines editorial responsibility with SEO, localization, structured content, and database management. I also lead a team of three employees responsible for automotive data entry and database maintenance.

## Key Strengths

- Senior-level editorial judgment and content management
- Strong Arabic writing and editing; fluent English
- English-to-Arabic translation and localization
- SEO strategy and search-focused content development
- Research, fact-checking, and content quality assurance
- Digital publishing and CMS workflows
- Audience-focused content development
- Cross-functional collaboration with UX, development, and operations
- Automotive subject-matter expertise
- AI-assisted content workflows and willingness to develop further in AI evaluation and annotation
