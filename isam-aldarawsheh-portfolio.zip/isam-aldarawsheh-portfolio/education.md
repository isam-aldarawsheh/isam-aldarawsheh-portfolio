# Education & Professional Development

## Bachelor's Degree

**Bachelor's Degree in Media and Journalism / E-Journalism**  
Arab Open University — Amman, Jordan

## Certificates

- Media and Press — Arab Youth Media Forum, 2010
- News Editing for Broadcast — Jordan Media Institute, 2011
- Media and Press — Highlights for Media Training, 2013

## Languages

- Arabic — Native
- English — Fluent
- German — Beginner
